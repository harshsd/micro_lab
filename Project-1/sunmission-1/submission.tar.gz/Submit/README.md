Team: 
Puneet Nemade-16D070003,
Harsh Deshpande-16D070011,
Viraj Nadkarni-16D070013,
Navoj Ramesh-16D070059

Main entity name: microprocessor in file microprocessor.vhd



